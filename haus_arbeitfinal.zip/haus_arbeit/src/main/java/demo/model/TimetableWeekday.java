package demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Time;
import java.time.LocalTime;


@Table(name = "timetable_weekday")
@NamedQueries({
        @NamedQuery(name = "TimetableWeekday.findById", query = "SELECT t FROM TimetableWeekday  t WHERE t.user_id = :user_id GROUP BY t.weekday "),
})
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TimetableWeekday implements Serializable {
    @Id
    private Integer user_id;
   @Id
    private Integer weekday;
    @Column(name = "start_time", nullable = false)
    private String startTime;
    @Column(name = "end_time", nullable = false)
    private String endTime;



}
