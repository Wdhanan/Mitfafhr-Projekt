package demo.api.dto;

import demo.model.TimetableWeekdayID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.IdClass;
import java.io.Serializable;
import java.sql.Time;


@AllArgsConstructor
@NoArgsConstructor
@Data
@SuppressWarnings("serial")

public class TimetableWeekdayDtoIn implements Serializable {

    @Id
    private Integer user_id;
    @Id
    private Integer weekday;
    public String start_time;
    public String end_time;

    @Override
    public String toString() {
        return "TimetableWeekdayDtoIn{" +
                "user_id=" + user_id +
                ", weekday=" + weekday +
                ", startTime='" + start_time + '\'' +
                ", endTime='" + end_time + '\'' +
                '}';
    }

}
