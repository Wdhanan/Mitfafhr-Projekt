package demo.api.dto;

import demo.model.TimetableWeekday;
import demo.model.TimetableWeekdayID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.IdClass;
import java.io.Serializable;
import java.sql.Time;

@Data
@NoArgsConstructor @AllArgsConstructor
public class TimetableWeekdayDtoOut implements Serializable {
    private String user_id;
    private Integer weekday;
    @Column(name = "start_time", nullable = false)
    private String startTime;
    @Column(name = "end_time", nullable = false)
    private String endTime;

    public TimetableWeekdayDtoOut(TimetableWeekday t) {
        this.user_id = String.valueOf(t.getUser_id());
        this.weekday = t.getWeekday();
        this.startTime = t.getStartTime();
        this.endTime = t.getEndTime();
    }


    public TimetableWeekdayDtoOut(TimetableWeekday[] t) {
        for (int i = 0; i < t.length; i++) {
            this.user_id = String.valueOf(t[i].getUser_id());
            this.weekday = t[i].getWeekday();
            this.startTime = t[i].getStartTime();
            this.endTime = t[i].getEndTime();
        }
    }
}
