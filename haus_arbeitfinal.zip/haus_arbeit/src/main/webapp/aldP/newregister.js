/**
 * 
 */


function newregister() {
	let file = document.getElementById("profilbild").files[0];
	var reader = new FileReader();

		
	reader.readAsDataURL(file);
	var vorname = document.getElementById("vorname").value;
	var nachname = document.getElementById("nachname").value;
	var strasse= document.getElementById("strasse").value;
	var nr= document.getElementById("nr").value;
	var plz= document.getElementById("plz").value;
	var ort= document.getElementById("ort").value;
	var email= document.getElementById("email").value;
	var benutzerId= document.getElementById("benutzerId").value;
	var password= document.getElementById("passwort").value;
	var profilbild= reader.result;
	
	var data = {vorname,nachname,strasse,nr,plz,ort,email,benutzerId,password,profilbild};
				
	registerUser(data);

}

function xxxxx(){
	let file = document.getElementById("profilbild").files[0];
	var reader = new FileReader();
			
	if (file) {
		
		reader.readAsDataURL(file);
				var vorname = document.getElementById("vorname").value;
				var nachname = document.getElementById("nachname").value;
				var strasse= document.getElementById("strasse").value;
				var nr= document.getElementById("nr").value;
				var plz= document.getElementById("plz").value;
				var ort= document.getElementById("ort").value;
				var email= document.getElementById("email").value;
				var benutzerId= document.getElementById("benutzerId").value;
				var password= document.getElementById("password").value;
				var profilbild= reader.result;
			
			alert("Bastian Lontsi");
			var data = {vorname,nachname,strasse,nr,plz,ort,email,benutzerId,password,profilbild};
			registerUser(data);
		
		reader.onerror = function(error) {
			console.log('Error: ', error);
		}
		
	}
	else {
		let data = {
			vorname: document.querySelector("#vorname").value,
				nachname: document.querySelector("#nachname").value,
				strasse: document.querySelector("#strasse").value,
				nr: document.querySelector("#nr").value,
				plz: document.querySelector("#plz").value,
				ort: document.querySelector("#ort").value,
				email: document.querySelector("#email").value,
				benutzerId: document.querySelector("#benutzerId").value,
				password: document.querySelector("#password").value,
				profilbild: ""
		};
		registerUser(data);
	}}

function registerUser(data) {
	
	fetch('demo/access', {
		method: 'post',
		headers: {
			'Content-type': 'application/json'
		},
		body: JSON.stringify(data)
	})
		.then(response => {
			if (!response.ok) {
				document.querySelector("#registerError").innerHTML = "Ein Fehler ist aufgetreten!";
				throw Error(response.url);
			}
			alert(response.json());
			return response.json();
		})
		.then(data => {
			console.log("Login Token " + data);
			sessionStorage.setItem('loginToken', data.token);
			showNotesView();
			setUserLabel();
			getNotes();
		})
		.catch(error => {
			sessionStorage.removeItem('loginToken');
			console.error('Error:', error);
		});
}

