/**
 * 
 */

// With strict mode, you can not, for example, use undeclared variables.
"using strict";

window.onload = function() {	
	
	
}



//Variable
let punkt  = [49.250723, 7.211122];
let text = "Hallo Leute";


let map = L.map('map').setView([49.250723, 7.377122], 13);

    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        maxZoom: 18, // max. possible 23
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'pk.eyJ1IjoiYmFzdGlhbm5lYnJhIiwiYSI6ImNsM241bTE2eTBiZzEzcG55cmczYWQ4eG4ifQ.JxHb7uqSxwSkAWX-CYG79Q'
    }).addTo(map);


//Maker 
L.marker([49.250723, 7.377122],{opacity:3.0}).addTo(map);

//Maker With Image
var myIcon = L.icon({
    iconUrl: url('imgs/profile-2.png'),
    iconSize: [100, 100],
    iconAnchor: [50, 104],
    popupAnchor: [-3, -76],
    shadowUrl: url('imgs/profile-1.png'),
    shadowSize: [68, 95],
    shadowAnchor: [22, 94]
});

L.marker([49.250723, 7.298122], {icon: myIcon}).addTo(map);

//Popup with Image
L.popup({
	autoClose:false,
	className:'popup-user',
}).setLatLng(punkt)
.setContent(text)
.openOn(map);

//Popup
L.popup()
    .setLatLng([49.250723, 7.297144])
    .setContent("I am a standalone popup.")
    .openOn(map);


function showUser() {
	
	
	let latitude1 = "65768";
	let latitude2 = "67658";
	let longitude = "65768";
	let name = "Bastian Lontsi";
	
	var affich = document.getElementById('list_etudiant');
	
	for(let i = 0; i< 4; i++){
		affich.innerHTML += "<div>" + latitude1 + " "+latitude2 + " Longitude " + longitude + "</br>"; 
		affich.innerHTML += "Image" + "</br>";
		affich.innerHTML += "<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.</p>"+
		"<p>Donec nec justo eget felis facilisis fermentum. Aliquam porttitor mauris sit amet orci. Aenean dignissim pellentesque felis. </p>"+ "</br> </div>";
	}
	
	
}


//Autre Script


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Functions accessing AccessController
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

function login() {

	
	let data = {
		username: document.querySelector("#loginUsername").value,
		password: document.querySelector("#loginPassword").value
	};
	
	fetch('demo/access', {
		method: 'post',
		headers: {
			'Content-type': 'application/json'
		},
		body: JSON.stringify(data)
		
		
	})
		.then(response => response.json())
		.then(data => {
			console.log("Login Token " + data);
			//sessionStorage.setItem('loginToken', data.token);
			
			consol.log(data);
			
		})
		.catch((error) => {
			console.error('Error:', error);
			sessionStorage.removeItem('loginToken');
			document.querySelector("#loginError").innerHTML = "Es ist ein Fehler aufgetreten!";
		});
}


function logout() {
	let id = sessionStorage.getItem('loginToken');

	fetch('app/access' + '/' + id, {
		method: 'delete'
	})
		.then(response => {
			if (response.ok) {
				sessionStorage.removeItem('loginToken');
				showLoginView();
			}
		})
		.catch(error => console.error('Error:', error));
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Functions accessing UserController
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Functions accessing NoteController
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

function getNotes() {
	let id = sessionStorage.getItem('loginToken');

	fetch('app/notes' + '/' + id)
		.then(response => response.json() )
		.then(data => printListe(data))
		.catch(error => console.error('Error:', error));
}

function clearNotes() {
	let id = sessionStorage.getItem('loginToken');

	fetch('app/notes' + '/' + id, { method: 'DELETE' })
		.then(response => getNotes())
		.catch(error => console.error('Error:', error));
}

function addNote() {
	let id = sessionStorage.getItem('loginToken');

	let data = {
		subject: document.querySelector("#subject").value,
		content: document.querySelector("#content").value,
	};

	fetch('app/notes' + '/' + id, {
		method: 'post',
		headers: {
			'Content-type': 'application/json'
		},
		body: JSON.stringify(data)
	})
		.then(response => getNotes())
		.catch(error => console.error('Error:', error));
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Utility Functions
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

function printListe(data) {
	document.querySelector("#subject").value = "";
	document.querySelector("#content").value = "";

	let div = document.querySelector("#notelist");
	div.innerHTML = "";
	let ul = document.createElement("ul");
	div.append(ul);

	console.log(data);

	data.forEach(item => {
		let li = document.createElement("li");
		li.append(item.date + " : " + item.subject + " => " + item.content);
		ul.append(li);
	});
}

function clearLoginErrorMessage() {
	document.querySelector("#loginError").innerHTML = "";
}

function clearRegisterErrorMessage() {
	document.querySelector("#registerError").innerHTML = "";
}



function setUserLabel() {
	let userId = sessionStorage.getItem('loginToken');
	if (userId != null) {
		fetch('app/users' + '/' + userId)
			.then(response => response.json())
			.then(data => {
				console.log("Data = " + data.username)
				document.querySelector("#labelUsername").innerHTML = data.username;
				if (data.profileImage.length > 10) {
					document.querySelector("#labelImage").setAttribute(
						'src', data.profileImage);
				}
				else
				{
					document.querySelector("#labelImage").setAttribute(
						'src', 'profil.jpg');
				}
			})
			.catch(error => console.error('Error:', error));
	}
}


//=========================================================================
// Visibility Control Functions
//-------------------------------------------------------------------------

function showNotesView() {
	let divLogin = document.querySelector("#login");
	let divRegister = document.querySelector("#register");
	let divNotes = document.querySelector("#notes");

	divLogin.style.display = 'none';
	divRegister.style.display = 'none';
	divNotes.style.display = 'inline';
}

function showLoginView() {
	/***
		
		clearLoginErrorMessage();
		let divLogin = document.querySelector("#login");
		let divRegister = document.querySelector("#register");
		let divNotes = document.querySelector("#notes");
	
		divLogin.style.display = 'none';
		divRegister.style.display = 'none';
		divNotes.style.display = 'none';
	
		document.querySelector("#loginUsername").value = "";
		document.querySelector("#loginPassword").value = "";
		
	 */
}

function on() {
	 document.getElementById("overlay").style.display = "block";

}

function off() {
  document.getElementById("overlay").style.display = "none";
}