/**
 * 
 */


function register() {

	let file = document.getElementById("profilbild").files[0];
	var reader = new FileReader();

	if (file) {
		reader.readAsDataURL(file);
		reader.onload = function() {
			let data = {
				1: document.getElementById("vorname").value,
				2: document.getElementById("password1").value,
				3 : document.getElementById("vorname").value,
				4 : document.getElementById("nachname").value,
				5: document.getElementById("email").value,
				6: document.getElementById("strasse").value,
				7: document.getElementById("nr").value,
				8: document.getElementById("plz").value,
				9: document.getElementById("ort").value,
			};

			registerUser(data);
		};
		
	}
	else {
		let data = {
			1 : document.getElementById("vorname").value,
				2: document.getElementById("password1").value,
				3 : document.getElementById("vorname").value,
				4 : document.getElementById("nachname").value,
				5: document.getElementById("email").value,
				6: document.getElementById("strasse").value,
				7: document.getElementById("nr").value,
				8: document.getElementById("plz").value,
				9: document.getElementById("ort").value,
		};
		registerUser(data);
	}
}


function registerUser(data) {
	console.log(data);
	
	fetch('demo/access', {
		method: 'post',
		headers: {
			'Content-type': 'application/json'
		},
		body: JSON.stringify(data)
	})
		.then(response => {
			console.log(response.ok);
			if (!response.ok) {
				
				document.querySelector("#registerError").innerHTML = "Ein Fehler ist aufgetreten!";
				throw Error(response.statusText);
			}
			return response.json();
		})
		.then(data => {
			console.log("Login Token " + data);
			sessionStorage.setItem('loginToken', data.token);
			
			alert("Gut");
			
			//Show different view
			
		})
		.catch(error => {
			sessionStorage.removeItem('loginToken');
			console.error('Error:', error);
		});
}

