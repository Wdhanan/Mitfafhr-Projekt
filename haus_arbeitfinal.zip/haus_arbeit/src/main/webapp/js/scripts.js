window.onload = function() {

	let token = sessionStorage.getItem('loginToken');

	if (token != null) {
		setVisibilityHeader(true);
		setVisibility("find-ride-container", false);
		hidenAsideElement();
	}
	else {
		setVisibility("find-ride-container", true);
		setVisibilityHeader(false);
		//hidenAsideElement();
		hidenStundenplanElement();
	}
	
    initMap();


};

let myMap,latitude,longitude;

latitude = 49.250723;
longitude = 7.377122;

function initMap() {
    myMap = L.map('map-container').setView([49.250723, 7.377122], 12);

    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>, <a href="https://www.flaticon.com/free-icons/address" title="address icons">Address icons created by DinosoftLabs - Flaticon</a>',
        maxZoom: 18, // max. possible 23
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw'
    }).addTo(myMap);

    
    userMarker(latitude,longitude);
}


/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////Maker/////////////////////////////////

function userMarker(longitude,latitude){
	let marker = L.marker([latitude, longitude]).addTo(myMap);
	marker.on('click',event=>changeColor(event));


}

function changeColor(event) {

}

function firstUser(longitude,latitude){

	var meinIcon = L.icon({
		iconUrl:'/imgs/home-location.png',
		iconSize:[50,55]
	});

	L.marker([latitude, longitude],{icon:meinIcon}).addTo(myMap);


}
    
/////////////////////////////////////////////////////////////////


function setVisibility(elementId, visible) {
	const element1 = document.querySelector("#stundenPlan");
    const element = document.getElementById(elementId);
    
    if(visible === true) {
        element.classList.remove("hidden");
    } else {
        element.classList.add("hidden")
		element1.classList.add("hidden");
		showMap();
    }
}

//Set Visibility von Element in Header

function setVisibilityHeader(visible) {

    const element1 = document.querySelector("#hiddenBeforLogin1");
    const element2 = document.querySelector("#hiddenBeforLogin2");
    
    //Login and Register Button selected
    const element3 = document.querySelector("#hiddenAfterLogin1");
    const element4 = document.querySelector("#hiddenAfterLogin2");
    
    if(visible === true) {
        element1.classList.remove("hidden");
        element2.classList.remove("hidden");
        
        //Login and Register Button Element Hidden
        element3.classList.add("hidden");
        element4.classList.add("hidden");
    } else {
        element1.classList.add("hidden")
        element2.classList.add("hidden")
        
        //Login and Register Button Element Show
        element3.classList.remove("hidden");
        element4.classList.remove("hidden");
    }
}

//Visibility von Studenplan Elemet

function setVisibilityStundenPlanElement(visible){

	const element = document.querySelector("#stundenplan");
	const element1 = document.querySelector("#map-container");
	const element2 = document.querySelector("#asideElement");
	
	if(visible === false){
		element.classList.remove("hidden");
		element1.classList.remove("hidden");
		element2.classList.remove("hidden");
	}else{
		element.classList.add("hidden");
		element1.classList.add("hidden");
		element2.classList.add("hidden");
	}
}

// get Element with function event
function getStundenPlanFormular(){
	
	document.querySelector("#asideElement").style.display="none";
	let token = sessionStorage.getItem('loginToken');
	const element1 = document.querySelector("#stundenPlan");
	const element2 = document.querySelector("#map-container");
	
	if(token != null){
		element1.classList.remove("hidden");
		element2.classList.add("hidden");
	}
	
}

//Show form-aside
function getAsideElement(){
	const element = document.querySelector("#asideElement");
	element.classList.remove("hidden");
}

//Get Element Mitfarergelegenheit
function getMitfarergelegenheitenFormx(){
	
	document.querySelector("#asideElement").style.display="block";
	let token = sessionStorage.getItem('loginToken');
	const element = document.querySelector("#find-ride-container");
	const element1 = document.querySelector("#stundenPlan");
	const element2 = document.querySelector("#map-container");
	
	if(token != null){
		element.classList.remove("hidden");
		
		element1.classList.add("hidden");
		element2.classList.remove("hidden");
	}
}

//Get Element aside von mitFahrengelegenheit

function getMitfarergelegenheitenForm1(){
	let token = sessionStorage.getItem('loginToken');
}

//Hidden asside Element
function hidenAsideElement(){
	const element = document.querySelector("#asideElement");
	element.classList.add("hidden");
}

//Hidden Stundenplan
function hidenStundenplanElement(){
	const element1 = document.querySelector("#stundenPlan");
	element1.classList.add("hidden");
}

//Show map
function showMap(){
	const element3 = document.querySelector("#map-container");
	element3.classList.remove("hidden");
}

//Get Form neuer User Registrieren
function neurUserRegistrieren(){
	var registerForm = document.getElementById("neuUserRegister");
	document.querySelector("#neuUserRegister").style.display = "block";
}

// Hidden Form neuer User register
function abbrechen(){
	document.querySelector("#neuUserRegister").style.display = "none";
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getUserInfo(userId) {

	return fetch("demo/access/userInfo", {
		method: 'get',
		headers: {
			'Content-type': 'application/json'
		}
	});
}


//Icon
var redIcon = L.icon({
	iconUrl: "./icon/marker-icon-red.png",
	shadowUrl: "./icon/marker-shadow.png",
	iconSize: [25,41],
	iconAnchor: [12,41],
	popupAnchor: [1,-34],
	shadowSize: [41,41],
});

var blueIcon = L.icon({
	iconUrl: "./icon/marker-icon-blue.png",
	shadowUrl: "./icon/marker-shadow.png",
	iconSize: [25,41],
	iconAnchor: [12,41],
	popupAnchor: [1,-34],
	shadowSize: [41,41],
});

function suchen(){


	let token = sessionStorage.getItem('loginToken');

	var fahrt = document.getElementById("fahrt").value;
	var hinfahrt = document.getElementById("ruckfahrt").value;
	var hinruckfahrt = document.getElementById("hinruckfahrt").value;
	var distance = document.getElementById("distance").value;
	var weeks = document.getElementById("weeks").value;
	var time = document.getElementById("time").value;



	fetch('demo/user?distance='+ distance + "&token="+ token, {
		method: 'get',
		headers: {
			'Content-type': 'application/json'
		},
	})
		.then(response => response.json())
		.then(data => {
			console.log(data);


			for (let i=0;i<data.length;i++){

				if (data[i].position.latitude != sessionStorage.getItem("current_user_latitude") && data[i].position.longitude != sessionStorage.getItem("current_user_longide")){
					var maker = L.marker([data[i].position.latitude, data[i].position.longitude],{
						icon: blueIcon
					}).addTo(myMap);
				}

				maker.on('click',event=>changeIcon(event,data))

				var mytable = document.getElementById("myTable");
				//User Infos
				var userName = data[i].username + " "+ data[i].lastname;
				var userEmail = data[i].email;
				var userAdresse = data[i].street +""+data[i].streetNumber
					+", "+data[i].zip+ " "+data[i].city;

				var row = `<div style="background-color:white;font-size:10px;margin-top: 2px;   display: grid;row-gap: 50px;grid-template-columns: auto auto auto;padding: 5px;">
                <div style="border: 1px solid rgba(0, 0, 0, 0);
							  padding: 10px;
							  font-size: 10px;
							  text-align: center;">
                    <img alt="" src="imgs/profile-2.png" style="height:50px;width:50px;">
                </div>

                <div style="border: 1px solid rgba(0, 0, 0, 0);
					  padding: 10px;
					  font-size: 10px;
					  text-align: center;">
                    <table>
                    <tr>
                        <td>${userName}</td>
                        <td>${userEmail}</td>
                        <td>${userAdresse}</td>
                    </tr>
                    </table>
                </div>
            </div>`;
				mytable.innerHTML += row;
				console.log(data[i].position.latitude);
			}

			console.log("Login Token " + data.token);

		})
		.catch((error) => {
			console.error('Error:', error);
			sessionStorage.removeItem('loginToken');
			document.querySelector("#loginError").innerHTML = "Es ist ein Fehler aufgetreten!";
		});

}

function changeIcon(event,data) {
	console.log(event.latlng);
	console.log(event.latlng.lat);

	L.marker([event.latlng.lat, event.latlng.lng],{
		icon: redIcon
	}).addTo(myMap);
}

