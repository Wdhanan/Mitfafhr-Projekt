/**
 * 
 */

function logout() {
	let id = sessionStorage.getItem('loginToken');

	if(id != null){
		
		fetch('demo/access' + '?tokenId=' + id, {
		method: 'delete'
		})
		.then(response => {
			if (response.ok) {
				sessionStorage.removeItem('loginToken');
				setVisibilityHeader(false);
				
				setVisibility("find-ride-container", false);
				showMap();
			}
		})
		.catch(error => console.error('Error:', error));
	}
		
}